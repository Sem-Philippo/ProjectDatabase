﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SomerenModel
{
    public enum Stock
    {
        Empty,
        Nearly_Depleted,
        Sufficient
    }
}
