﻿namespace SomerenModel
{
    public class Teacher
    {
        public string Name { get; set; }
        public int AgeInYears { get; set; }
        public string PhoneNumber { get; set; } 
    }
}